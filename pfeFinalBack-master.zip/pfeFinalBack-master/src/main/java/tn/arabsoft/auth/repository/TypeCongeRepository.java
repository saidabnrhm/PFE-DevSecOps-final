package tn.arabsoft.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.arabsoft.auth.entity.TypeConge;


public interface TypeCongeRepository extends JpaRepository<TypeConge, Long>{

}
