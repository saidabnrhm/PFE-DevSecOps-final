package tn.arabsoft.auth.entity;

public enum ERole {
	ROLE_PERSONNEL,
	ROLE_ADMIN,
	ROLE_CHEF

}
