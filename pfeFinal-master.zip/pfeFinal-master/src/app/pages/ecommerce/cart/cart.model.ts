export interface Cart {
    image: string;
    name: string;
    color: string;
    price: string;
    quantity: number;
    total: string;
}
